prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 203
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>8169627338385120
,p_default_application_id=>203
,p_default_id_offset=>0
,p_default_owner=>'BAB'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF40000010A494441545847638CCA58FB9F610001E3A8034643603404464360D087C0AF1FEF19A425051838D81918D455A530CACC6B379E30FC6760C55A96DE7FF8928183';
wwv_flow_imp.g_varchar2_table(2) := '4B146F394BB024FCFFE71D8394A4080323C36F062D0D19921CF0FAF53B863F0C0294394054F03F838E9602032BCB6F061F576D0CC336EDBCC2F0F71F1B564B6EDC7ACCF0FCF5BF21EE0016860F0CA2A24223380A4089505E4E82E1FFBF9F0C867A8A18F1';
wwv_flow_imp.g_varchar2_table(3) := '79FDE613869FBF99B0C6F39B37EF19BEFDE2A63C0DA8ABCA327071FE6370B655C7306CE3F64B0C4CCC9C3812E12386371FB03B0EA68160361CF05C309A087F7C7BCDA0282F4E56367CF6FC0303230B1F658990D60D66828970D401A321301A02A32140EB';
wwv_flow_imp.g_varchar2_table(4) := '10000014A3DDE1C6D752AB0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(7410458868190640)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
