prompt --application/shared_components/plugins/process_type/com_ceramig_carbonita_process
begin
--   Manifest
--     PLUGIN: COM.CERAMIG.CARBONITA.PROCESS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>3900410554576167
,p_default_application_id=>203
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(11402723678639691)
,p_plugin_type=>'PROCESS TYPE'
,p_name=>'COM.CERAMIG.CARBONITA.PROCESS'
,p_display_name=>'carbonita.process'
,p_supported_component_types=>'APEX_APPLICATION_PAGE_PROC:APEX_APPL_AUTOMATION_ACTIONS:APEX_APPL_TASKDEF_ACTIONS'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('PROCESS TYPE','COM.CERAMIG.CARBONITA.PROCESS'),'')
,p_api_version=>2
,p_execution_function=>'carbonita_plugin_pkg.plugin_process'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'0.4'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(11601498213090998)
,p_plugin_id=>wwv_flow_imp.id(11402723678639691)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'server_url'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'http://10.1.1.142:80/'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(11600284889077462)
,p_plugin_id=>wwv_flow_imp.id(11402723678639691)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'process_query_json'
,p_attribute_type=>'SQL'
,p_is_required=>true
,p_default_value=>'select JSON_ARRAYAGG(json_object(ename,job)) val from emp'
,p_is_translatable=>false
,p_examples=>'select JSON_ARRAYAGG(json_object(ename,job)) val from emp'
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(11600501634082260)
,p_plugin_id=>wwv_flow_imp.id(11402723678639691)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'template_statix'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(11600825803086438)
,p_plugin_id=>wwv_flow_imp.id(11402723678639691)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'report_name'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(11601113461087453)
,p_plugin_id=>wwv_flow_imp.id(11402723678639691)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'report_type'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_is_translatable=>false
);
wwv_flow_imp.component_end;
end;
/
