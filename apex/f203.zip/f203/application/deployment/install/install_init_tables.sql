prompt --application/deployment/install/install_init_tables
begin
--   Manifest
--     INSTALL: INSTALL-init_tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>3900410554576167
,p_default_application_id=>203
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12201378089950000)
,p_install_id=>wwv_flow_imp.id(12200264568944409)
,p_name=>'init_tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --CARBONITA_CALLS: 1/10000 rows exported, APEX$DATA$PKG/CARBONITA_CALLS$348407',
'    apex_data_install.load_supporting_object_data(p_table_name => ''CARBONITA_CALLS'', p_delete_after_install => true );',
'    --CARBONITA_TEST: 1/10000 rows exported, APEX$DATA$PKG/CARBONITA_TEST$917503',
'    apex_data_install.load_supporting_object_data(p_table_name => ''CARBONITA_TEST'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
